#-*- codeing = utf-8 -*-
#@Time : 2021/9/5 22:15
#@Author : Allinvain
#@File : t-sne.py
#@Software: PyCharm
# coding='utf-8'
"""t-SNE对手写数字进行可视化"""
from time import time
import numpy as np
import matplotlib.pyplot as plt
from sklearn.manifold import TSNE
import os
import re

#load_data读取存储在文件中的节点embedding和label并返回，画图只需要这两个数据
def load_data(emb_path, label_path):
    emb1 = np.load(emb_path)
    label = np.genfromtxt(label_path, dtype=np.int)
    return emb1, label

def main():
    data, label = load_data('./chameleon_gprgnn.npy', './chameleon.label')#读取数据集的embedding和标签
    print('Computing t-SNE embedding')
    tsne = TSNE(n_components=2, init='pca', random_state=0)
    t0 = time()
    result = tsne.fit_transform(data)
    #先利用tsne对节点的嵌入进行拟合(降维)，即tsne.fit_transform(data)，因为要把高维的节点可视化到二维的平面上
    #需要降维降维结果存储在result里面
    t1 = time()
    fig = plt.figure(figsize=(8, 8))#定义一个8 * 8大小的画布
    from matplotlib.ticker import NullFormatter
    print("t-SNE: %.2g sec" % (t1 - t0))  #记录拟合（降维）算法用时
    ax = fig.add_subplot(1, 1, 1)
    for i in range(label.shape[0]):
    #依次遍历所有的节点，根据节点所属类别涂上不同的颜色，节点的坐标已经在fit_transform这一步拟合出来了，当前要做的
    #就是根据拟合好的二维坐标把点画出来，此外根据类别涂上不同的颜色
        if label[i] == 0:
            plt.scatter(result[i, 0], result[i, 1], c='slateblue', cmap=None)
            #result是二维的数组，result[i, 0]代表第i个节点的横坐标，rsult[i, 1]代表纵坐标
            #c='slateblue'代表颜色类型，每个颜色对应的字符串可以在 https://www.jb51.net/article/184682.htm
            #查找
        elif label[i] == 1:
            plt.scatter(result[i, 0], result[i, 1], c='darkgoldenrod', cmap=None)
        elif label[i] == 2:
            plt.scatter(result[i, 0], result[i, 1], c='forestgreen', cmap=None)
        elif label[i] == 3:
            plt.scatter(result[i, 0], result[i, 1], c='maroon', cmap=None)
        else:#因为chameleon数据集节点有5类，所以需要5个判断分支，根据数据集的节点类型数选择判断分支数
            plt.scatter(result[i, 0], result[i, 1], c='turquoise', cmap=None)
    ax.xaxis.set_major_formatter(NullFormatter())  # 设置标签显示格式为空
    ax.yaxis.set_major_formatter(NullFormatter())
    plt.axis('off')
    plt.savefig("./output/ours.png")
    #这里选择保存的格式，可选.pdf .eps和.png，根据论文格式需求自行选择
    plt.close()


if __name__ == '__main__':
    main()
