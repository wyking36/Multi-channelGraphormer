# -*- codeing = utf-8 -*-
# @Time : 2022/12/6 23:27
# @Author : Allinvain
# @File : draw.py
# @Software: PyCharm
import matplotlib.pyplot as plt

x = [0.1, 0.22, 0.31, 0.4, 0.47, 0.55, 0.62, 0.71, 0.79, 0.87, 0.96]
knn = [0.82, 0.817,  0.818,  0.817, 0.818, 0.819, 0.820, 0.820, 0.819, 0.8197,  0.820]


k1 = [0.45,  0.43,  0.40,  0.35, 0.36, 0.40, 0.58, 0.62, 0.85, 0.87, 0.92]  # 1-hop
k2 = [0.85,  0.83,  0.70,  0.57, 0.42, 0.36, 0.40, 0.45, 0.52, 0.75, 0.81]  # 2-hop
k3 = [0.69,  0.58,  0.47,  0.39, 0.40, 0.43, 0.51, 0.59, 0.62, 0.75, 0.80]

plt.plot(x, k1,'s-',label="1-hop")  # s-:方形一阶
plt.plot(x, k2, 'o-',label="2-hop")  # o-:圆形2阶
# plt.plot(x, k1,  label="1-hop")
# plt.plot(x, k2,  label="2-hop")
plt.plot(x, k3, 'p-', label="3-hop")
plt.plot(x, knn, '*-',color='lightseagreen', label="kNN") #'*-'

# plt.axis([0.9, 6.1, 78, 87])  # Texas  # 手动调节坐标轴取值范围[x1, x2, y1, y2]
# plt.axis([0.9, 6.1, 70, 90])  # Cora  #
fontsize = 30
plt.grid()
plt.xlabel("homophily ratio", horizontalalignment="center",fontsize=15)  # 横坐标名字
plt.ylabel("accuracy", fontsize=15) # 纵坐标名字
plt.legend(loc = "best", fontsize=11) #图例
# plt.title("cora")
# plt.xticks(fontsize=15)
# plt.yticks(fontsize=15)
plt.show()  # 看图用这个, 要存图要注释掉这行
# plt.savefig(f'k_analysis_hetero.pdf')
# plt.savefig(f'k_analysis_homo.pdf')
