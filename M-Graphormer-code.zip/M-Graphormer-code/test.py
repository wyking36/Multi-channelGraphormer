# -*- codeing = utf-8 -*-
# @Time : 2022/8/30 17:11
# @Author : Allinvain
# @File : test.py.py
# @Software: PyCharm
import numpy as np
print("hello")
import torch
import numpy as np

# arr = np.load("/data/user/wmx/U-GCN-main/cora20.npy")
# print(arr.shape)
# import os
# ten = torch.tensor([[1, 2, 3], [4, 5, 6], [7, 8, 9]], dtype=torch.float64)
# print(torch.mean(ten, dim=0))
# #huibianma
# idx = np.load(os.path.join("./data/{}/".format("chameleon"), 'train_val_test_idx.npz'))
# idx_train = idx['train_idx']
# idx_test = idx['test_idx']
# idx_val = idx['val_idx']
# import numpy as np
# train = np.loadtxt("idx/train.txt")
# print(train)
# # print(type(a[0]))