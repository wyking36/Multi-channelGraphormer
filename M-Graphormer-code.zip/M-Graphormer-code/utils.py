import scipy.sparse as sp
import torch
import numpy as np
import os

def accuracy(output, labels):
    preds = output.max(1)[1].type_as(labels)
    correct = preds.eq(labels).double()
    correct = correct.sum()
    return correct / len(labels)

def sparse_mx_to_torch_sparse_tensor(sparse_mx):
    """Convert a scipy sparse matrix to a torch sparse tensor."""
    sparse_mx = sparse_mx.tocoo().astype(np.float32)
    indices = torch.from_numpy(np.vstack((sparse_mx.row, sparse_mx.col)).astype(np.int64))
    values = torch.from_numpy(sparse_mx.data)
    shape = torch.Size(sparse_mx.shape)
    return torch.sparse.FloatTensor(indices, values, shape)

def parse_index_file(filename):
    """Parse index file."""
    index = []
    for line in open(filename):
        index.append(int(line.strip()))
    return index

def sample_mask(idx, l):
    """Create mask."""
    mask = np.zeros(l)
    mask[idx] = 1
    return np.array(mask, dtype=np.bool)

def sparse_to_tuple(sparse_mx):
    """Convert sparse matrix to tuple representation."""
    def to_tuple(mx):
        if not sp.isspmatrix_coo(mx):
            mx = mx.tocoo()
        coords = np.vstack((mx.row, mx.col)).transpose()
        values = mx.data
        shape = mx.shape
        return coords, values, shape

    if isinstance(sparse_mx, list):
        for i in range(len(sparse_mx)):
            sparse_mx[i] = to_tuple(sparse_mx[i])
    else:
        sparse_mx = to_tuple(sparse_mx)

    return sparse_mx

def normalize(mx):
    """Row-normalize sparse matrix"""
    rowsum = np.array(mx.sum(1))
    r_inv = np.power(rowsum, -1).flatten()
    r_inv[np.isinf(r_inv)] = 0.
    r_mat_inv = sp.diags(r_inv)
    mx = r_mat_inv.dot(mx)
    return mx

def encode_onehot(labels):
    classes = set(labels)
    classes_dict = {c: np.identity(len(classes))[i, :] for i, c in enumerate(classes)}
    labels_onehot = np.array(list(map(classes_dict.get, labels)), dtype=np.int32)
    return labels_onehot


# 这里是用于异质数据集的读取

def load_data(config):
    feature_list = []
    label_list = []
    f = open('./data/{}/out1_node_feature_label.txt'.format(config.data_set), 'r')
    #节点特征和标签在同一个文件
    for line in f.readlines():
        ele = line.strip().split('\t')
        if ele[0] == 'node_id':
            continue
        feature = ele[1]
        label = int(ele[2])
        feature = feature.strip().split(',')
        feature_list.append(feature)
        label_list.append(label)
    feature = np.array(feature_list, dtype=float)


    n = feature.shape[0]
    idx = np.array([i for i in range(n)])
    np.random.shuffle(idx)
    idx_train = idx[: int(n * 0.40)]
    idx_val = idx[int(n * 0.40): int(n * 0.50)]
    idx_test = idx[int(n * 0.50):]

    idx_train = torch.LongTensor(idx_train)
    idx_val = torch.LongTensor(idx_val)
    idx_test = torch.LongTensor(idx_test)
    labels = torch.LongTensor(label_list)
    features = sp.csr_matrix(feature, dtype=np.float32)
    features = torch.FloatTensor(np.array(features.todense()))

    return features, labels, idx_train, idx_val, idx_test

#这里是用于同质数据集（cora,citeseer)的读取
# def load_data(args):
#     """Load citation network dataset (cora only for now)"""
#     print('Loading {} dataset...'.format(args.data_set))
#
#     features = np.genfromtxt("{}{}/{}.feature".format(args.data_path, args.data_set, args.data_set), dtype=np.float32)
#     labels = np.genfromtxt("{}{}/{}.label".format(args.data_path, args.data_set, args.data_set), dtype=np.int32)#单列切片会自动降维
#     features = normalize_features(sp.csr_matrix(features))
#
#     if args.data_set in ['cora']:
#         # n = features.shape[0]
#         # idx = np.array([i for i in range(n)], dtype=int)
#         # np.random.shuffle(idx)
#
#
#         idx_train = np.loadtxt("idx/train.txt")
#         idx_val = np.loadtxt("idx/val.txt")
#         idx_test = np.loadtxt("idx/test.txt")
#         # np.savetxt("idx/train.txt", idx_train)
#         # np.savetxt("idx/val.txt", idx_val)
#         # np.savetxt("idx/test.txt", idx_test)
#     else:
#         idx = np.load("{}{}/train_val_test_idx.npz".format(args.data_path, args.data_set))
#         idx_train = idx['train_idx']
#         idx_test = idx['test_idx']
#         idx_val = idx['val_idx']
#     idx_train = torch.LongTensor(idx_train)
#     idx_val = torch.LongTensor(idx_val)
#     idx_test = torch.LongTensor(idx_test)
#
#
#
#     features = torch.FloatTensor(np.array(features.todense()))
#     labels = torch.LongTensor(labels)#1表示返回（跨列）列的索引,哪个元素为1则返回所在列号
#
#     return features, labels, idx_train, idx_val, idx_test

def normalize_adj(mx):
    """Row-normalize sparse matrix"""
    rowsum = np.array(mx.sum(1))
    r_inv_sqrt = np.power(rowsum, -0.5).flatten()
    r_inv_sqrt[np.isinf(r_inv_sqrt)] = 0.
    r_mat_inv_sqrt = sp.diags(r_inv_sqrt)
    return mx.dot(r_mat_inv_sqrt).transpose().dot(r_mat_inv_sqrt)


def normalize_features(mx):
    """Row-normalize sparse matrix,稀疏矩阵的行归一化"""
    rowsum = np.array(mx.sum(1))
    r_inv = np.power(rowsum, -1).flatten()
    r_inv[np.isinf(r_inv)] = 0.
    r_mat_inv = sp.diags(r_inv)
    mx = r_mat_inv.dot(mx)
    return mx

#用于异质数据集的load_graph
def load_graph(dataset, config):
    print('Loading {} dataset...'.format(dataset))

    struct_edges = np.genfromtxt(config.structgraph_path, dtype=np.int32)
    sedges = np.array(list(struct_edges), dtype=np.int32).reshape(struct_edges.shape)
    sadj = sp.coo_matrix((np.ones(sedges.shape[0]), (sedges[:, 0], sedges[:, 1])), shape=(config.n, config.n),
                         dtype=np.float32)
    sadj = sadj + sadj.T.multiply(sadj.T > sadj) - sadj.multiply(sadj.T > sadj)
    nsadj = normalize(sadj + sp.eye(sadj.shape[0]))
    #nsadj是归一化后的adj

    featuregraph_path = config.featuregraph_path + str(config.k) + '.txt'
    #featuregraph_path=./data/cornell/knn/c3.txt
    #c3代表的3nn
    feature_edges = np.genfromtxt(featuregraph_path, dtype=np.int32)
    #读取的是根据相似度top-k节点构造出来的拓扑结构（边对形式）
    fedges = np.array(list(feature_edges), dtype=np.int32).reshape(feature_edges.shape)
    fadj = sp.coo_matrix((np.ones(fedges.shape[0]), (fedges[:, 0], fedges[:, 1])), shape=(config.n, config.n),
                         dtype=np.float32)
    fadj = fadj + fadj.T.multiply(fadj.T > fadj) - fadj.multiply(fadj.T > fadj)
    nfadj = normalize(fadj + sp.eye(fadj.shape[0]))
    #nfadj表示用knn生成且归一化的特征构造出来的拓扑


    adj_2_edges = np.genfromtxt(config.adjgraph_path, dtype=np.int32)
    adj2edges = np.array(list(adj_2_edges), dtype=np.int32).reshape(adj_2_edges.shape)
    adj2 = sp.coo_matrix((np.ones(adj2edges.shape[0]), (adj2edges[:, 0], adj2edges[:, 1])), shape=(config.n, config.n),
                         dtype=np.float32)
    adj2 = adj2 + adj2.T.multiply(adj2.T > adj2) - sadj.multiply(adj2.T > adj2)
    nsadj2 = normalize(adj2 + sp.eye(adj2.shape[0]))
    #nsadj2是归一化的二阶top（去除了一阶邻居）

    nsadj = torch.FloatTensor(np.array(nsadj.todense()))
    nsadj2 = torch.FloatTensor(np.array(nsadj2.todense()))
    nfadj = torch.FloatTensor(np.array(nfadj.todense()))
    #分别代表归一化的

    return nsadj, nsadj2, nfadj


#用于同质数据集cora的load_graph

# def load_graph(dataset, args):
#     """Load citation network dataset (cora only for now)"""
#     print('Loading {} dataset...'.format(args.data_set))
#
#     edges = np.genfromtxt("{}".format(args.structgraph_path), dtype=np.int32)
#     adj = sp.coo_matrix((np.ones(edges.shape[0]), (edges[:, 0], edges[:, 1])), shape=(args.n, args.n), dtype=np.float32)
#     adj = adj + adj.T.multiply(adj.T > adj) - adj.multiply(adj.T > adj)
#
#     edges2 = np.genfromtxt("{}".format(args.adjgraph_path), dtype=np.int32)
#     adj2 = sp.coo_matrix((np.ones(edges2.shape[0]), (edges2[:, 0], edges2[:, 1])), shape=(args.n, args.n), dtype=np.float32)
#     adj2 = adj2 + adj2.T.multiply(adj2.T > adj2) - adj2.multiply(adj2.T > adj2)
#
#     featuregraph_path = args.featuregraph_path + str(args.k) + '.txt'
#     edgesk = np.genfromtxt("{}".format(featuregraph_path), dtype=np.int32)
#     adjk = sp.coo_matrix((np.ones(edgesk.shape[0]), (edgesk[:, 0], edgesk[:, 1])), shape=(args.n, args.n),
#                          dtype=np.float32)
#     adjk = adjk + adjk.T.multiply(adjk.T > adjk) - adjk.multiply(adjk.T > adjk)
#
#     adj = normalize_adj(adj + sp.eye(adj.shape[0]))
#     adj2 = normalize_adj(adj2 + sp.eye(adj2.shape[0]))
#     adjk = normalize_adj(adjk + sp.eye(adjk.shape[0]))
#
#     adj = torch.FloatTensor(np.array(adj.todense()))
#     adj2 = torch.FloatTensor(np.array(adj2.todense()))
#     adjk = torch.FloatTensor(np.array(adjk.todense()))
#     return adj, adj2, adjk

#用于citeseer的load_graph,用的是geom那个
# def load_graph(dataset, args):
#     """Load citation network dataset (cora only for now)"""
#     print('Loading {} dataset...'.format(args.data_set))
#
#     edges = np.genfromtxt("{}".format(args.structgraph_path), dtype=np.int32)
#     adj = sp.coo_matrix((np.ones(edges.shape[0]), (edges[:, 0], edges[:, 1])), shape=(args.n, args.n), dtype=np.float32)
#     adj = adj + adj.T.multiply(adj.T > adj) - adj.multiply(adj.T > adj)
#
#     #自己构建二阶拓扑
#     adj2 = np.array(adj.todense())
#     adj2 = np.matmul(adj2, adj2)
#     adj2 = sp.coo_matrix(adj2)
#
#     # edges2 = np.genfromtxt("{}".format(args.adjgraph_path), dtype=np.int32)
#     # adj2 = sp.coo_matrix((np.ones(edges2.shape[0]), (edges2[:, 0], edges2[:, 1])), shape=(args.n, args.n), dtype=np.float32)
#     # adj2 = adj2 + adj2.T.multiply(adj2.T > adj2) - adj2.multiply(adj2.T > adj2)
#
#     featuregraph_path = args.featuregraph_path + str(args.k) + '.txt'
#     edgesk = np.genfromtxt("{}".format(featuregraph_path), dtype=np.int32)
#     adjk = sp.coo_matrix((np.ones(edgesk.shape[0]), (edgesk[:, 0], edgesk[:, 1])), shape=(args.n, args.n),
#                          dtype=np.float32)
#     adjk = adjk + adjk.T.multiply(adjk.T > adjk) - adjk.multiply(adjk.T > adjk)
#
#     adj = normalize_adj(adj + sp.eye(adj.shape[0]))
#     adj2 = normalize_adj(adj2 + sp.eye(adj2.shape[0]))
#     adjk = normalize_adj(adjk + sp.eye(adjk.shape[0]))
#
#     adj = torch.FloatTensor(np.array(adj.todense()))
#     adj2 = torch.FloatTensor(np.array(adj2.todense()))
#     adjk = torch.FloatTensor(np.array(adjk.todense()))
#     return adj, adj2, adjk
