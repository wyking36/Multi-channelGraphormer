# -*- codeing = utf-8 -*-
# @Time : 2022/9/6 17:16
# @Author : Allinvain
# @File : construct.py
# @Software: PyCharm
import numpy as np
import math

def construct_graph(dataset, features, topk):
    fname = '../data/' + dataset + '/knn/tmp.txt'
    f = open(fname, 'w')
    ##### Kernel
    # dist = -0.5 * pair(features) ** 2
    # dist = np.exp(dist)

    #### Cosine
    dist = math.cos(features)
    inds = []
    for i in range(dist.shape[0]):
        ind = np.argpartition(dist[i, :], -(topk + 1))[-(topk + 1):]
        inds.append(ind)

    for i, v in enumerate(inds):
        for vv in v:
            if vv == i:
                pass
            else:
                f.write('{} {}\n'.format(i, vv))
    f.close()


def adj_knn(dataset):
    for topk in range(2, 10):
        print(topk)
        if dataset in ["texas", "wisconsin", "chameleon", "squirrel","cornell"]:
            feature = []
            f = open('../data/' + dataset + '/' + 'out1_node_feature_label.txt', 'r')
            for line in f.readlines():
                ele = line.strip().split('\t')
                if ele[0] == 'node_id':
                    continue
                feature.append(ele[1].split(','))
        elif dataset in ["citeseer", "pubmed"]:
            feature = sp.load_npz(os.path.join("../data/{}/{}_features.npz".format(dataset, dataset))).toarray()

        elif dataset in ["cora"]:
            idx_features_labels = np.genfromtxt("{}{}/{}.content".format("../data/", dataset, dataset),
                                                dtype=np.dtype(str))
            feature = sp.csr_matrix(idx_features_labels[:, 1:-1], dtype=np.float32)

        else:
            feature = np.loadtxt('../data/{}/{}.feature'.format(dataset, dataset), dtype=float)

        # feature = np.array(features,dtype=float)
        construct_graph(dataset, feature, topk)
        f1 = open('../data/' + dataset + '/knn/tmp.txt','r')
        f2 = open('../data/' + dataset + '/knn/c' + str(topk) + '.txt', 'w')
        lines = f1.readlines()
        for line in lines:
            start, end = line.strip('\n').split(' ')
            if int(start) < int(end):
                f2.write('{} {}\n'.format(start, end))
        f2.close()

# if __name__ == "__main__":
