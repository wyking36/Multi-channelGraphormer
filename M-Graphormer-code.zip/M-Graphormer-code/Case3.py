# -*- codeing = utf-8 -*-
# @Time : 2022/10/27 17:45
# @Author : Allinvain
# @File : Case3.py
# @Software: PyCharm
# -*- codeing = utf-8 -*-
# @Time : 2022/10/27 17:39
# @Author : Allinvain
# @File : Case3.py
# @Software: PyCharm
#构建用于ours的数据集，通过调节同类与不同类间的链接概率，从而动态调节异质性率，注意三个类的特征分布是不一样的


import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import multivariate_normal
import numpy as np
from sklearn.manifold import TSNE
import matplotlib.pyplot as plt

edge_file = open("./manual/case_0.8.edge", 'w')

adj = np.zeros((900, 900))
for i in range(300):  # 类内链接概率0.03.可以通过此来调整异质性率
    for j in range(i + 1, 300):
        z = np.random.randint(0, 100, dtype=int)
        if z > 96:  # 0.03
            adj[i, j] = 1
            adj[j, i] = 1

for i in range(300, 600):
    for j in range(i + 1, 600):
        z = np.random.randint(0, 100, dtype=int)
        if z > 96:  # 0.03
            adj[i, j] = 1
            adj[j, i] = 1

for i in range(600, 900):
    for j in range(i + 1, 900):
        z = np.random.randint(0, 100, dtype=int)
        if z > 96:  # 0.03
            adj[i, j] = 1
            adj[j, i] = 1


#同质边数的计算公式为（299+0）*300/2*3*0.03=4037
#异质边数的计算公式为 300*300*3*0.0035=945
#同质率为：4037/(4037+945) = 0.81
#类间概率
for i in range(300):
    for j in range(300, 600):
        z = np.random.randint(0, 10000, dtype=int)
        if z > 9984:  # 0.0015，#类间链接概率0.0015
            adj[i, j] = 1
            adj[j, i] = 1

for i in range(300):
    for j in range(600, 900):
        z = np.random.randint(0, 10000, dtype=int)
        if z > 9984:  # 0.0015
            adj[i, j] = 1
            adj[j, i] = 1

for i in range(300, 600):
    for j in range(600, 900):
        z = np.random.randint(0, 10000, dtype=int)
        if z > 9984:  # 0.0015
            adj[i, j] = 1
            adj[j, i] = 1

x, y = np.where(adj > 0)
for i in range(len(x)):
    if x[i] != y[i]:
        edge_file.write('{} {}\n'.format(x[i], y[i]))
edge_file.close()




dim = 50
mask_convariance_maxtix = np.diag([1 for i in range(dim)])


#三个类别协方差相同，但分布中心不同
center1 = 2.5 * np.random.random(size=dim) - 1
center2 = 2.5 * np.random.random(size=dim) - 1
center3 = 2.5 * np.random.random(size=dim) - 1




center = np.vstack((center1, center2, center3))

data1 = multivariate_normal.rvs(mean=center1, cov=mask_convariance_maxtix, size=300)
data2 = multivariate_normal.rvs(mean=center2, cov=mask_convariance_maxtix, size=300)
data3 = multivariate_normal.rvs(mean=center3, cov=mask_convariance_maxtix, size=300)
data = np.vstack((data1, data2, data3))


label = np.array([0 for i in range(300)] + [1 for i in range(300)] + [2 for i in range(300)])

permutation = np.random.permutation(label.shape[0])

data = data[permutation, :]
label = label[permutation]

np.savetxt('./manual/case_0.8.feature', data, fmt='%f')
np.savetxt('./manual/case_0.8.label', label, fmt='%d')