import torch.nn as nn
import torch.nn.functional as F
from layers import GraphConvolution, GraphAttention, SelfAttentionLayer, gcnmask, FFN
from torch.nn.parameter import Parameter
import torch
import numpy as np
import math
# class GAT(nn.Module):
#     def __init__(self, nfeat, nhid, nclass, dropout, alpha, nheads):
#         """Dense version of GAT."""
#         super(GAT, self).__init__()
#         self.dropout = dropout
#
#         self.attentions = [GraphAttention(nfeat, nhid, dropout=dropout, alpha=alpha, concat=True) for _ in range(nheads)]
#         for i, attention in enumerate(self.attentions):
#             self.add_module('attention_{}'.format(i), attention)
#
#         self.out_att = GraphAttention(nhid * nheads, nclass, dropout=dropout, alpha=alpha, concat=False)
#
#     def forward(self, x, adj):
#         x = F.dropout(x, self.dropout, training=self.training)
#         x = torch.cat([att(x, adj) for att in self.attentions], dim=1)
#
#         x = F.dropout(x, self.dropout, training=self.training)
#         x = F.elu(self.out_att(x, adj))
#         return F.log_softmax(x, dim=1)



class Attention(nn.Module):
    def __init__(self, in_size, hidden_size=8):
        super(Attention, self).__init__()

        self.project = nn.Sequential(
            nn.Linear(in_size, hidden_size),
            nn.Tanh(),
            nn.Linear(hidden_size, 1, bias=False)
        )

    def forward(self, z):
        w = self.project(z)
        beta = torch.softmax(w, dim=1)
        # print(beta.mean(dim=0))
        return (beta * z).sum(1), beta

# class SFGCN(nn.Module):
#     def __init__(self, nfeat, nhid1, nhid2, nclass, dropout, alpha, nheads):
#         super(SFGCN, self).__init__()
#
#         # use GCN or GAT
#         self.SGAT1 = GAT(nfeat, nhid1, nhid2, dropout, alpha, nheads)
#         self.SGAT2 = GAT(nfeat, nhid1, nhid2, dropout, alpha, nheads)
#         self.SGAT3 = GAT(nfeat, nhid1, nhid2, dropout, alpha, nheads)
#
#         self.dropout = dropout
#         # self.a = nn.Parameter(torch.zeros(size=(nhid2, 1)))
#         # nn.init.xavier_uniform_(self.a.data, gain=1.414)
#         self.attention = Attention(nhid2)
#         self.tanh = nn.Tanh()
#
#         self.MLP = nn.Sequential(
#             nn.Linear(nhid2, nclass),
#             nn.LogSoftmax(dim=1)
#         )
#
#     def forward(self, x, sadj, sadj2, fadj):
#         emb1 = self.SGAT1(x, sadj) # Special_GAT out1 -- sadj structure graph
#         emb2 = self.SGAT2(x, sadj2) # Special_GAT out2 -- sadj2 feature graph
#         emb3 = self.SGAT3(x, fadj)  # Special_GAT out3 -- fadj feature graph
#         emb = torch.stack([emb1, emb2, emb3], dim=1)
#         emb, att = self.attention(emb)
#         emb = self.MLP(emb)
#         #emb.shape=(183,16)
#         return emb, att, emb1, emb2, emb3



class MGraphormer(nn.Module):
    def __init__(self, in_dim, hid_dim, hid_dim2, n_class, n_heads, dropout, alpha):
        super(MGraphormer, self).__init__()
        self.dropout = dropout
        self.graphTransformer1 = GraphTransformer(in_dim, hid_dim, n_heads, dropout, alpha)
        self.graphTransformer2 = GraphTransformer(in_dim, hid_dim, n_heads, dropout, alpha)
        self.graphTransformer3 = GraphTransformer(in_dim, hid_dim, n_heads, dropout, alpha)
        #分别对应3个不同的通道
        self.attention = Attention(hid_dim)
        self.tanh = nn.Tanh()
        self.ffn = nn.Sequential(
            nn.Linear(hid_dim, n_class),
            nn.LogSoftmax(dim=1)
        )
    def forward(self, x, sadj1, sadj2, fadj):
        emb1 = self.graphTransformer1(x, sadj1)  # Special_GAT out1 -- sadj structure graph
        emb2 = self.graphTransformer2(x, sadj2)  # Special_GAT out2 -- sadj2 feature graph
        emb3 = self.graphTransformer3(x, fadj)  # Special_GAT out3 -- fadj feature graph
        emb = torch.stack([emb1, emb2, emb3], dim=1)
        emb, att = self.attention(emb)
        # print(type(emb.shape))
        temp_emb = emb.cpu().detach().numpy()
        np.save('./chameleon70.npy', temp_emb)

        emb = self.ffn(emb)
        #emb存储的是三个adj得到的emb加权和，att存储每个adj的softmax后的att
        return emb, att, emb1, emb2, emb3



class GraphTransformer(nn.Module):
    def __init__(self, in_dim, hid_dim, n_heads, dropout, alpha):
        super(GraphTransformer, self).__init__()
        self.dropout = dropout
        self.alpha = alpha
        self.attentions = [SelfAttentionLayer(in_dim, hid_dim, dropout=dropout, alpha=alpha) for _ in range(n_heads)]
        for i, att in enumerate(self.attentions):
            self.add_module('attention_{}'.format(i), att)

    def forward(self, x, adj):
        x = F.dropout(x, self.dropout, training=self.training)
        result = torch.mean(torch.stack([att(x, adj) for att in self.attentions], dim=0), dim=0)
        return result


